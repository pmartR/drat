#' pmartRdata
#'
#' The pmartRdata package contains example datasets compatible with the pmartR
#' package. These datasets include unlabeled (LC-MS/MS) and isobaric labeled
#' (TMT) peptide, protein, metabolites (GC-MS and NMR), lipids (both negative
#' and positive LC-MS ionization modes), and RNAseq. Some of the datasets were
#' generated as part of the same experiments, as described below.
#' 
#'
#' @section Data types:
#'
#' Experiment 1 Data: Host response to virus using human cells. This experiment
#' includes isobaric labeled peptide data (TMT), negative and positive
#' ionization mode LC-MS lipidomics data, and RNAseq data. Sample names across
#' the different data types from this experiment have been harmonized, to allow
#' data integration. These data are a deidentified subset from an experiment
#' that has not yet been published. Samples included in this subset consist of
#' human cells infected with one of three virus strains.
#'
#' Experiment 2 Data: Human tissue samples. This experiment includes unlabeled
#' peptide data (LC-MS/MS), the associated protein data, and metabolomics data
#' (GC-MS). Sample names across the different data types from this experiment
#' have been harmonized, to allow data integration. Note that the These data are
#' a deidentified subset from an experiment that has not yet been published.
#' Samples included in this subset consist of tissue samples from humans
#' exhibiting three primary phenotypes.
#'
#' NMR Data: Tomato plant samples. These data are publicly available via Biais
#' et al. (reference listed below). Samples in this experiment each come from
#' one of four different time points.
#'
#' Technical Replicates Peptide Data: Mouse plasma samples. These data are a
#' subset of the data used in Webb-Robertson et al. (reference listed below) and
#' include biological samples associated with one of two levels of a factor, a
#' dilution level of mouse plasma to Shewanella Oneidensis MR-1, and a technical
#' replicate (two technical replicates per biological sample).
#' 
#' @section Data formats:
#'
#'   Each type of data is provided in two formats. The first format is an S3
#'   object class used by the R package \code{pmartR}. Data available as S3
#'   objects 'pepData', 'proData', 'metabData', 'lipidData', ‘nmrData’, and
#'   ‘seqData’ are created by \code{\link[pmartR]{as.pepData}},
#'   \code{\link[pmartR]{as.proData}}, \code{\link[pmartR]{as.metabData}},
#'   \code{\link[pmartR]{as.lipidData}}, \code{\link[pmartR]{as.nmrData}},
#'   \code{\link[pmartR]{as.seqData}}, respectively. The second format
#'   corresponds to the individual components of the S3 object classes,
#'   \code{e_data} - biomolecule expression data, \code{f_data} – sample meta
#'   information, and \code{e_meta} – biomolecule expression meta data. See
#'   \code{pmartR} for more details.
#'
#' @references Webb-Robertson BJ, Matzke MM, Datta S, Payne SH, Kang J, Bramer
#'   LM, Nicora CD, Shukla AK, Metz TO, Rodland KD, Smith RD, Tardiff MF,
#'   McDermott JE, Pounds JG, Waters KM (2014), \emph{Bayesian proteoform
#'   modeling improves protein quantification of global proteomic measurements}.
#'   Molecular & Cellular Proteomics. doi: 10.1074/mcp.M113.030932.
#' @references Biais B, Benard C, Beauvoit B, Colombie S, Prodhomme D, Menard G, 
#'   Bernillon S, Gehl B, Gautier H, Ballias P, et al. (2014), \emph{Remarkable 
#'   reproducibility of enzyme activity profiles in tomato fruits grown under 
#'   contrasting environments provides a roadmap for studies of fruit metabolism}.
#'   Plant Physiol 164 (3), 1204-1221. doi: 10.1104/pp.113.231241.
#'
#' @docType package
#' @name pmartRdata
#' @rdname pmartRdata
#'
#' @seealso \code{\link[pmartR]{as.lipidData}}
#' @seealso \code{\link[pmartR]{as.metabData}}
#' @seealso \code{\link[pmartR]{as.nmrData}}
#' @seealso \code{\link[pmartR]{as.pepData}}
#' @seealso \code{\link[pmartR]{as.proData}}
#' @seealso \code{\link[pmartR]{as.seqData}}
NULL
