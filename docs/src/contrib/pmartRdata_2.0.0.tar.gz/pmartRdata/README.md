# pmartRdata

This R package contains data from a systems virology study with proteomics, metabolomics, and lipidomics measurements available. Used for illustration purposes in [pmartRqc](https://github.com/pmartR/pmartRqc).

``` r
devtools::install_github("pmartR/pmartRdata")
```