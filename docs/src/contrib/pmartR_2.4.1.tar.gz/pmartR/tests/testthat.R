library(testthat)
library(pmartR)

test_check("pmartR")
