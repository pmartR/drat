#' @importFrom foreach %dopar%
#' @export
foreach::`%dopar%`
